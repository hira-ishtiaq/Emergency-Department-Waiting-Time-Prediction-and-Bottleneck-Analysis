import os, random, sys, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from min_heap import MinHeap
from simulation import generate_patients, simulate, WARMUP_MIN


class TestMinHeap(unittest.TestCase):
    def test_sorted_output_and_heap_property(self):
        rng, h = random.Random(1), MinHeap()
        keys = [rng.randint(0, 50) for _ in range(500)]
        for k in keys:
            h.push(k, k)
            self.assertTrue(h.is_valid_heap())
        out = [h.pop()[0] for _ in range(len(keys))]
        self.assertEqual(out, sorted(keys))

    def test_stable_ties(self):
        h = MinHeap()
        for name in "abcde":
            h.push(1, name)
        self.assertEqual([h.pop()[1] for _ in range(5)], list("abcde"))

    def test_tuple_priority(self):
        h = MinHeap()
        h.push((5, 0), "minor"); h.push((1, 9), "critical"); h.push((1, 3), "critical-earlier")
        self.assertEqual([h.pop()[1] for _ in range(3)], ["critical-earlier", "critical", "minor"])

    def test_empty(self):
        h = MinHeap()
        with self.assertRaises(IndexError): h.pop()
        with self.assertRaises(IndexError): h.peek()

    def test_peek_does_not_remove(self):
        h = MinHeap(); h.push(3, "x"); h.push(1, "y")
        self.assertEqual(h.peek(), (1, "y")); self.assertEqual(len(h), 2)


class TestSimulation(unittest.TestCase):
    def setUp(self):
        self.pats, self.h = generate_patients(4, 5.0, 7)

    def test_everyone_leaves_and_times_are_consistent(self):
        df, _ = simulate(self.pats, self.h, 3, 1, 1, "heap")
        self.assertEqual(len(df), len(self.pats))
        self.assertTrue(df["depart"].notna().all())
        self.assertTrue((df[["triage_wait", "doctor_wait", "door_to_doctor_min", "los_min"]] >= -1e-9).all().all())
        self.assertTrue((df["doctor_start"] >= df["triage_end"] - 1e-9).all())

    def test_heap_helps_critical_patients(self):
        h, _ = simulate(self.pats, self.h, 3, 1, 1, "heap")
        f, _ = simulate(self.pats, self.h, 3, 1, 1, "fifo")
        crit = lambda d: d[d.severity == 1]["door_to_doctor_min"].mean()
        self.assertLess(crit(h), crit(f))

    def test_same_patients_both_policies(self):
        h, _ = simulate(self.pats, self.h, 3, 1, 1, "heap")
        f, _ = simulate(self.pats, self.h, 3, 1, 1, "fifo")
        self.assertEqual(sorted(h.pid), sorted(f.pid))


if __name__ == "__main__":
    unittest.main()


class TestLiveED(unittest.TestCase):
    def test_matches_batch_simulator(self):
        from live_ed import LiveED
        pats, horizon = generate_patients(3, 5.0, 11)
        batch, _ = simulate(pats, horizon, 3, 1, 1, "heap")
        live = LiveED(3, 1, 1, "heap")
        for p in pats:
            live.admit_spec(p)
        live.drain()
        rec = live.records().sort_values("pid").reset_index(drop=True)
        batch = batch.sort_values("pid").reset_index(drop=True)
        for col in ("door_to_doctor_min", "los_min", "triage_wait"):
            self.assertTrue(((rec[col] - batch[col]).abs() < 1e-6).all(), col)

    def test_critical_called_first_and_time_passes(self):
        from live_ed import LiveED
        ed = LiveED(1, 1, 1, "heap", seed=3)
        for i in range(6):                       # clog the single doctor / nurse
            ed.admit(f"minor{i}", 5)
        ed.advance(30)
        crit = ed.admit("critical", 1)
        order = [p["name"] for p in ed.waiting_list("triage")]
        self.assertEqual(order[0], "critical")   # jumps every waiting minor patient
        ed.advance(500)
        self.assertEqual(ed.in_system, 0)
        self.assertTrue(ed.records()["doctor_start"].notna().all())
        self.assertGreater(ed.now, 0)

    def test_waits_never_negative(self):
        from live_ed import LiveED
        ed = LiveED(2, 1, 1, "heap", seed=5)
        for _ in range(40):
            ed.admit_random(); ed.advance(3)
        ed.advance(2000)
        r = ed.records()
        self.assertTrue((r[["triage_wait", "doctor_wait", "door_to_doctor_min", "los_min"]] >= -1e-9).all().all())
